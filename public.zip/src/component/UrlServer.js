// const UrlServer =
// "http://6243-2405-201-5507-301e-9561-22a0-e139-8e03.ngrok.io/api";
// "http://8633-2405-201-5507-301e-9561-22a0-e139-8e03.ngrok.io/api";

const UrlServer = "http://3.109.60.168:8000/api/";

export default UrlServer;
